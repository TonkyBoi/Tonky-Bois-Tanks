//steel forge
const steel-forge = extendContent(GenericSmelter, "steel-forge", {
	load() {
		this.super$load();
		this.regions = [];
		this.regions[0] = Core.atlas.find(this.name);
		this.regions[1] = Core.atlas.find(this.name + "-top");
	}
});
//brick kiln
const brick-kiln = extendContent(GenericSmelter, "brick-kiln", {
	load() {
		this.super$load();
		this.regions = [];
		this.regions[0] = Core.atlas.find(this.name);
		this.regions[1] = Core.atlas.find(this.name + "-top");
	}
});
//clay mixer load
const clay-mixer = extendContent(GenericCrafter, "clay-mixer", { 
	load() {
		this.super$load();
		this.regions = [];
		this.regions = [0] Core.atlas.find(this.name);
		this.regions = [1] Core.atlas.find(this.name + "-bottom");
		this.regions = [2] Core.atlas.find(this.name + "-liquid");
		this.regions = [3] Core.atlas.find(this.name + "-rotator");
		this.regions = [4] Core.atlas.find(this.name + "-top");
	}
});
//clay mixer draw
clay-mixer.buildType = () => extendContent(GenericCrafter.GenericCrafterBuild, clay-mixer, {
	draw() {
		Draw.rect(clay-mixer.regions[1], this.x, this.y);
		var liquid = clay-mixer.consumes.get(ConsumeType.liquid).liquid;
		Drawf.liquid(clay-mixer.regions[2], this.x, this.y, this.liquids.get(liquid)
		Draw.rect(clay-mixer.regions[3], this.x, this.y, this.totalProgress * 3)
		Draw.rect(clay-mixer.regions[4], this.x, this.y);
	}
});